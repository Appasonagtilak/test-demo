import java.awt.SystemTray;

public class Excp {
	
	static void avg()throws ArithmeticException
	{
		int a,b,c;
		try
		{
			a=2;
			b=10;
			c=b/a;
			System.out.println("this line will be not print here=="+c);
			//throw new ArithmeticException("demo");
		}
		catch(ArithmeticException e)
		{
			System.out.println("Exception caught");
		}
	}

	public static void main(String[] args) {
			
			try
			{
				avg();
			}
			catch(ArithmeticException e)
			{
				System.out.println("Arithmetic Exception is thown");
			}
			finally
			{
				System.out.println("Finally block is always executed");
			}
			System.out.println("Exception is hanled here.");
	}

}
