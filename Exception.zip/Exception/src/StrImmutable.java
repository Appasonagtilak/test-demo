
public class StrImmutable {

	public static void main(String[] args) {
		String s="Hello";
		String str=s.concat("Java");
		s.concat("Java");
		System.out.println("S="+s);
		System.out.println("Str="+str);

	}

}
