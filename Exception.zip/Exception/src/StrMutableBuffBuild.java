
public class StrMutableBuffBuild {

	public static void main(String[] args) {
		String str="Hello";
		str.concat("world");
		System.out.println(str);
		
		StringBuffer str1=new StringBuffer("Hello");
		str1.append("world");
		System.out.println("UsingBuffer="+str1);
		System.out.println(str1.reverse());
		
		StringBuilder st=new StringBuilder("Hello");
		st.append("world");
		System.out.println("UsingBuilder="+st);
		System.out.println(st.reverse());
	}

}
